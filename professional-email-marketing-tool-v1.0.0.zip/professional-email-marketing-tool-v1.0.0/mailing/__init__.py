# Core mailing package
