# 📦 Installation Guide# Инструкция по установке



## 🚀 Quick Installation## Пошаговая установка



### Prerequisites### 1. Системные требования

- **Python 3.9+** (Проверьте: `python --version`)- Python 3.10 или выше

- **pip** (Включен в Python 3.4+)- 200 МБ свободного места на диске

- **Интернет-соединение** для API доступа- Интернет соединение



### 1️⃣ Установка### 2. Подготовка окружения

```bash

```bash# Создание виртуального окружения

# Создание виртуального окруженияpython -m venv .venv

python -m venv .venv

# Активация окружения

# Активация окружения# macOS/Linux:

source .venv/bin/activate  # Linux/Macsource .venv/bin/activate

# или# Windows:

.venv\Scripts\activate     # Windows.venv\Scripts\activate

```

# Установка зависимостей

pip install -r requirements.txt### 3. Установка зависимостей

``````bash

pip install -r requirements.txt

### 2️⃣ Конфигурация```



```bash### 4. Настройка API ключей

# Копирование файла конфигурации

cp .env.example .env#### Resend (рекомендуется)

1. Зарегистрируйтесь на https://resend.com

# Редактирование настроек2. Создайте API ключ в панели управления

# Linux/Mac: nano .env3. Настройте домен для отправки

# Windows: notepad .env

```### 5. Конфигурация

Создайте файл `.env` с настройками:

**Обязательные настройки в `.env`:**```env

```bash# Resend настройки

# Resend API ключ (получите на resend.com)RESEND_API_KEY=re_your_key_here

RESEND_API_KEY=re_xxxxxxxxxxRESEND_FROM_EMAIL=noreply@yourdomain.com

RESEND_FROM_NAME=Your Company

# Email отправителя (должен быть верифицирован в Resend)

SENDER_EMAIL=noreply@yourdomain.com# Или Mailgun настройки

MAILGUN_API_KEY=your_mailgun_key

# Опциональные настройкиMAILGUN_DOMAIN=yourdomain.com

CONCURRENCY=3          # Параллельность отправкиMAILGUN_FROM_EMAIL=noreply@yourdomain.com

DAILY_QUOTA=1000      # Дневной лимит

LOG_LEVEL=INFO        # Уровень логирования# Общие настройки

DEBUG=false           # Отладочный режимDAILY_EMAIL_LIMIT=100

```CONCURRENCY=10

```

### 3️⃣ Проверка установки

### 6. Первый запуск

```bash```bash

# Тест CLI# Запуск GUI приложения

python -m mailing.cli --helppython run_gui.py

```

# Запуск веб-интерфейса

python run_gui.py## Проверка установки

```

### Тест конфигурации

## 🌐 Настройка Resend API```bash

# Проверка dry-run режима

1. **Регистрация**: Зарегистрируйтесь на [resend.com](https://resend.com)python -m mailing.cli --file samples/recipients.csv --template samples/template.html --subject "Test" --dry-run

2. **API ключ**: Создайте API ключ в панели управления```

3. **Домен**: Добавьте и верифицируйте ваш домен

4. **DNS настройки**: Добавьте необходимые DNS записи### Тест отправки

1. Откройте GUI приложение

## 🖥️ Системные требования2. Загрузите файл `samples/recipients.csv`

3. Выберите `samples/template.html`

| Компонент | Минимум | Рекомендуется |4. Нажмите "Тест" для проверки подключения

|-----------|---------|---------------|

| **Python** | 3.9+ | 3.11+ |## Возможные проблемы

| **RAM** | 256MB | 512MB+ |

| **Диск** | 100MB | 500MB+ |### Python не найден

| **ОС** | Windows 10, macOS 10.15, Ubuntu 18.04+ | Последние версии |- Убедитесь что Python 3.10+ установлен

- Проверьте переменную PATH

## 🚦 Первый запуск

### Ошибки pip

### Шаг 1: Веб-интерфейс```bash

```bash# Обновление pip

python run_gui.pypython -m pip install --upgrade pip

```

Откройте http://localhost:5001 в браузере# Установка через requirements

pip install -r requirements.txt --no-cache-dir

### Шаг 2: Тестовая рассылка```

```bash

python -m mailing.cli \### Проблемы с GUI

  --file samples/recipients.csv \- На Linux: `sudo apt-get install python3-tk`

  --template template.html \- На macOS: Установите через Homebrew

  --subject "Тест" \- Используйте CLI интерфейс как альтернативу

  --dry-run

```### API ошибки

- Проверьте правильность API ключей

## 🔧 Устранение проблем- Убедитесь в настройке домена

- Проверьте лимиты аккаунта

### ❌ Частые ошибки

## Поддержка

**1. ImportError / ModuleNotFoundError**

```bashПри проблемах проверьте:

# Решение: Активируйте виртуальное окружение1. Версию Python (`python --version`)

source .venv/bin/activate  # Linux/Mac2. Установленные пакеты (`pip list`)

.venv\Scripts\activate     # Windows3. Права доступа к файлам

```4. Настройки файрволла

**2. GUI не запускается (Qt проблемы)**
```bash
# Решение: Используйте веб-интерфейс
python minimal_web_gui.py
```

**3. API ошибки (401 Unauthorized)**
```bash
# Решение: Проверьте API ключ в .env
echo $RESEND_API_KEY  # Linux/Mac
```

**4. Email не отправляются**
- ✅ Проверьте верификацию домена в Resend
- ✅ Убедитесь что SENDER_EMAIL верифицирован
- ✅ Проверьте дневные лимиты в Resend

### 🆘 Диагностика

```bash
# Проверка конфигурации
python -c "from mailing.config import settings; print('✅ Конфигурация загружена')"

# Проверка API ключа
python -c "from mailing.config import settings; print('API ключ:', '✅ Установлен' if settings.resend_api_key else '❌ Не установлен')"

# Тест подключения
python -m mailing.cli --file samples/recipients.csv --template template.html --subject "Тест" --dry-run
```

## 📁 Структура после установки

```
email-marketing-tool/
├── .venv/                 # Виртуальное окружение
├── .env                   # Ваши настройки
├── .env.example          # Пример настроек
├── run_gui.py            # 🚀 Главная точка входа
├── minimal_web_gui.py    # 🌐 Веб-интерфейс
├── requirements.txt      # 📦 Зависимости
├── samples/              # 📁 Примеры
│   ├── recipients.csv   # Пример получателей
│   ├── template.html    # Пример шаблона
│   └── data.json       # Пример JSON
└── [остальные модули...]
```

## 🎯 Следующие шаги

1. **📧 Настройте Resend аккаунт** и верифицируйте домен
2. **📄 Подготовьте файлы получателей** (CSV/Excel/JSON)
3. **🎨 Создайте HTML шаблоны** с Jinja2 переменными  
4. **🧪 Протестируйте** с `--dry-run` опцией
5. **🚀 Запустите** реальную рассылку
6. **📊 Мониторьте** статистику в веб-интерфейсе

## 🔗 Полезные ссылки

- 📖 [Resend Documentation](https://resend.com/docs)
- 🎨 [Jinja2 Templates](https://jinja.palletsprojects.com/)
- 📧 [Email Best Practices](https://resend.com/docs/best-practices)

---

**Нужна помощь?** Проверьте логи приложения или используйте `--help` команды.