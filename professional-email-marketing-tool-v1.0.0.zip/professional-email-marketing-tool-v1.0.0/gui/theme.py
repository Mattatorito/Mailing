from __future__ import annotations
import platform, os
from PySide6.QtCore import QObject, Signal
from .design_system import LIGHT, DARK, Palette

class ThemeManager(QObject):
    themeChanged = Signal(bool)        # старый сигнал (сохранён для обратной совместимости)
    paletteChanged = Signal(Palette)   # новый сигнал с полной палитрой

    def __init__(self, mode: str | None = None):
        super().__init__()
        # mode: 'light' | 'dark' | 'auto'
        self._mode = mode or 'auto'
        self._is_dark = self._compute_dark_initial()
        self._palette: Palette = DARK if self._is_dark else LIGHT

    # ------------- Public API -------------
    def is_dark(self) -> bool: return self._is_dark
    def palette(self) -> Palette: return self._palette
    def mode(self) -> str: return self._mode

    def set_mode(self, mode: str):
        if mode not in ('light', 'dark', 'auto'):
            return
        if self._mode != mode:
            self._mode = mode
            self._apply_mode()

    def set_dark(self, dark: bool):
        # явное переключение переписывает режим на manual (light/dark)
        self._mode = 'dark' if dark else 'light'
        if self._is_dark != dark:
            self._is_dark = dark
            self._palette = DARK if dark else LIGHT
            self.themeChanged.emit(dark)
            self.paletteChanged.emit(self._palette)

    def toggle(self):
        self.set_dark(not self._is_dark)

    # ------------- Internal -------------
    def _compute_dark_initial(self) -> bool:
        if self._mode == 'light':
            return False
        if self._mode == 'dark':
            return True
        # auto mode heuristics
        env_pref = os.getenv('MAILING_GUI_THEME')  # dark/light
        if env_pref:
            return env_pref.lower().startswith('d')
        if platform.system() == 'Darwin':
            # macOS system theme detection
            try:
                import subprocess
                result = subprocess.run(
                    ['defaults', 'read', '-g', 'AppleInterfaceStyle'], 
                    capture_output=True, text=True, timeout=2
                )
                if result.returncode == 0 and 'Dark' in result.stdout:
                    return True
            except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
                pass
            # TODO: интеграция с системной темой через pyobjc (placeholder False)
            return False
        return False

    def _apply_mode(self):
        dark = self._compute_dark_initial()
        changed = dark != self._is_dark
        self._is_dark = dark
        new_palette = DARK if dark else LIGHT
        palette_changed = any(getattr(new_palette, f.name) != getattr(self._palette, f.name) for f in type(new_palette).__dataclass_fields__.values())
        self._palette = new_palette
        if changed:
            self.themeChanged.emit(dark)
        if changed or palette_changed:
            self.paletteChanged.emit(self._palette)

__all__ = ["ThemeManager"]
